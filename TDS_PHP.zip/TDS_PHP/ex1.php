<HTML>
<HEAD>
<TITLE></TITLE>
</HEAD>
<BODY>

<form name="connexion" method="post" action=ex1Validation.php>
	Nom:<input type="text" name="nom" id="nom"> <input name="valider" type="submit" value="Valider">

</form>
	
<?php

?>

</BODY>
</HTML>