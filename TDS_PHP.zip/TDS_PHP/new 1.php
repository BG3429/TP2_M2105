
<?php
include "ex1Validation.php";
foreach($_POST as $k=>$v){
	echo $k." : ".$v." <br>";
}
?>